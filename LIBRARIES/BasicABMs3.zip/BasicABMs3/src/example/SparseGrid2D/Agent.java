package example.SparseGrid2D;

import sim.engine.SimState;
import sim.engine.Steppable;
import states.SimStateSparseGrid2D;

@SuppressWarnings("serial")
public class Agent implements Steppable {
	int x;
	int y;
	int xdir;
	int ydir;

	public Agent(int x, int y, int xdir, int ydir) {
		super();
		this.x = x;
		this.y = y;
		this.xdir = xdir;
		this.ydir = ydir;
	}

	public void move(SimStateSparseGrid2D state) {
		x += xdir;
		y += ydir;
		x = state.acquireSpace().stx(x);		// assumes torus
		y = state.acquireSpace().sty(y);		// assumes torus
		state.acquireSpace().setObjectLocation(this, x, y);
		return;
	}

	public void step(SimState state) {
		move((Environment)state);
		return;
	}

}
