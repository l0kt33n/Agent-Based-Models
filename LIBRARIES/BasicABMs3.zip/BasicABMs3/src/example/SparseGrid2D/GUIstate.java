package example.SparseGrid2D;

import java.awt.Color;

import states.GUIStateSparseGrid2D;
import states.SimStateSparseGrid2D;

public class GUIstate extends GUIStateSparseGrid2D {

	public GUIstate(SimStateSparseGrid2D state, int gridWidth, int gridHeight, Color backdrop, Color agentDefaultColor,
			boolean agentPortrayal) {
		super(state, gridWidth, gridHeight, backdrop, agentDefaultColor, agentPortrayal);
	}

	public static void main(String[] args) {
		GUIstate.initialize(Environment.class, GUIstate.class, 400, 400, Color.WHITE, Color.RED, true);
	}

}
