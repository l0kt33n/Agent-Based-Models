package example.SparseGrid2D;

import states.SimStateSparseGrid2D;

@SuppressWarnings("serial")
public class Environment extends SimStateSparseGrid2D {
	public int gridWidth = 50;	//space width
	public int gridHeight = 50;	//space height
	public int n = 50;			// number of agents

	public Environment(long seed) {
		super(seed);
	}

	public void makeAgents() {
		for(int i = 0; i < n; i++) {
			int x = random.nextInt(gridWidth);
			int y = random.nextInt(gridHeight);
			int xdir = random.nextInt(3) - 1;
			int ydir = random.nextInt(3) - 1;
			Agent a = new Agent(x, y, xdir, ydir);
			schedule.scheduleRepeating(a);
			space.setObjectLocation(a, x, y);
		}
		return;
	}

	public int getGridWidth() {
		return gridWidth;
	}

	public void setGridWidth(int gridWidth) {
		this.gridWidth = gridWidth;
		return;
	}

	public int getGridHeight() {
		return gridHeight;
	}

	public void setGridHeight(int gridHeight) {
		this.gridHeight = gridHeight;
		return;
	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
		return;
	}

	public void start() {
		super.start();
		makeSpace(gridWidth, gridHeight);
		makeAgents();
		return;
	}

}
