package example.Continuous2D;

import sim.engine.SimState;
import sim.engine.Steppable;
import sim.util.Double2D;
import states.SimStateContinuous2D;

@SuppressWarnings("serial")
public class Agent implements Steppable {
	protected double x;
	protected double y;
	protected double xdir;
	protected double ydir;

	public Agent(double x, double y, double xdir, double ydir) {
		this.x = x;
		this.y = y;
		this.xdir = xdir;
		this.ydir = ydir;
	}

	public void move(SimStateContinuous2D state) {
		x += xdir;
		y += ydir;
		x = state.acquireSpace().stx(x);		// assumes torus
		y = state.acquireSpace().sty(y);		// assumes torus
		state.acquireSpace().setObjectLocation(this, new Double2D(x, y));
		return;
	}

	public void step(SimState state) {
		move((Environment)state);
		return;
	}

}
