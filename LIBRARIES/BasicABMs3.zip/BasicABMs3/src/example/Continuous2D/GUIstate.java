package example.Continuous2D;

import java.awt.Color;

import states.GUIStateContinuous2D;
import states.SimStateContinuous2D;

public class GUIstate extends GUIStateContinuous2D {
	
	public GUIstate(SimStateContinuous2D state, int gridWidth, int gridHeight, Color backdrop, Color agentDefaultColor,
			boolean agentPortrayal) {
		super(state, gridWidth, gridHeight, backdrop, agentDefaultColor, agentPortrayal);
	}

	public static void main(String[] args) {
		GUIstate.initialize(Environment.class, GUIstate.class, 400, 400, Color.WHITE, Color.RED, true);
	}

}
