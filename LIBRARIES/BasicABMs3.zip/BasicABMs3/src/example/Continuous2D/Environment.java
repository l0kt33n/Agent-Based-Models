package example.Continuous2D;

import sim.util.Double2D;
import states.SimStateContinuous2D;


@SuppressWarnings("serial")
public class Environment extends SimStateContinuous2D {
	public int n = 50; //the number of agents
	public double gridWidth = 50; //gridWidth
	public double gridHeight = 50; //gridHeight
	public double discretization = 1; 
	/*
	 * From the Continuous2D documentation:
	 * "The Continuous2D has been arranged to make neighborhood lookup information reasonably efficient.
	 * It discretizes the space into grid buckets.  The discretization size of the buckets is
	 * provided in the constructor and cannot be changed thereafter.  If the discretization was 0.7,
	 * for example, then one bucket would be (0,0) to (under 0.7, under 0.7), another bucket would be (0,0,0.7)
	 * to (under 0.7, under 1.4), etc."
	 */
	

	public Environment(long seed) {
		super(seed);
	}

	public double getGridWidth() {
		return gridWidth;
	}

	public void setGridWidth(double gridWidth) {
		this.gridWidth = gridWidth;
		return;
	}

	public double getGridHeight() {
		return gridHeight;
	}

	public void setGridHeight(double gridHeight) {
		this.gridHeight = gridHeight;
		return;
	}

	public double getDiscretization() {
		return discretization;
	}

	public void setDiscretization(double discretization) {
		this.discretization = discretization;
		return;
	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
		return;
	}
	
	public void makeAgents() {
		for (int i = 0; i < n; i++) {
			double x = random.nextDouble() * gridWidth;
			double y =  random.nextDouble() * gridHeight;
			double xdir = random.nextDouble() * 2 - 1;
			double ydir =  random.nextDouble() * 2 - 1;
			Agent a = new Agent(x, y, xdir, ydir);
			schedule.scheduleRepeating(a);
			space.setObjectLocation(a, new Double2D(x, y));
		}
		return;
	}
	 
	public void start() {
		super.start();
		makeSpace(discretization, gridWidth, gridHeight);
		makeAgents();
		return;
	}

}
