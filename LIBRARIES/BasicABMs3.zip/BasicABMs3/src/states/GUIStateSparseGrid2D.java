package states;

import java.awt.Color;
import java.lang.reflect.InvocationTargetException;
import javax.swing.JFrame;
import sim.display.Console;
import sim.display.Controller;
import sim.display.Display2D;
import sim.display.GUIState;
import sim.portrayal.grid.SparseGridPortrayal2D;
import sim.portrayal.simple.OvalPortrayal2D;


/**
 * <p>The GUIStateSparseGrid2D class extends GUIState in MASON; it allows you to
 * easily create a basic graphical user interface for a {@link SimStateSparseGrid2D}
 * simulation state. Create a child class of this class with a constructor like
 * the following:
 * 
 * <tt><pre>
 * public AgentsWithGUI(SimStateSparseGrid2D state, int gridWidth,
 * 		int gridHeight, Color backdrop, Color agentDefaultColor,
 * 		boolean agentPortrayal) {
 * 	super(state, gridWidth, gridHeight, backdrop, agentDefaultColor,
 * 			agentPortrayal);
 * }
 * </pre></tt>
 * 
 * Your child class of this class should implement a main method that uses {@link #initialize} as illustrated below:
 * 	
 * <tt><pre>
 * public static void main(String[] args) {
 * 	initialize([SimStateSparseGrid2D subclass].class,
 * 			[GUIStateSparseGrid2D subclass].class, 400, 400,
 * 			Color.WHITE, Color.BLUE, true);
 * 	System.exit(0);
 * }
 * </pre></tt>
 * 
 * For a complete explanation of the parameters, see the {@link #initialize} method documentation.
 * 
 * <p>You probably also want to override the <tt>public static String getName()</tt> method so as to return
 * a meaningful name for the simulation's GUI, like "MySimulation GUI".
 * 
 * <p>This class also provides several methods to set the color and/or size of individuals agents. See
 * the documentation for {@link #setOvalPortrayal2DColor(Object, float, float, float, float)},
 * {@link #setOvalPortrayal2DColor(Object, float, float, float, float, boolean)}, and
 * {@link #setOvalPortrayal2DColor(Object, float, float, float, float, boolean, double)} for
 * details.
 *
 * @author Jeffrey C. Schank
 * @author Matt L. Miller
 */
public class GUIStateSparseGrid2D extends GUIState {
	public Display2D display;
	public JFrame displayFrame;
	public SimStateSparseGrid2D stateSparseGrid;
	public int gridWidth;
	public int gridHeight;
	public Color backdrop;
	public Color agentDefaultColor;
	public boolean defaultPortrayal;

	public static Class<? extends GUIStateSparseGrid2D> theClass = null;
	public static SparseGridPortrayal2D agentsPortrayalSparseGrid;

	/**
	 * Create a {@link GUIStateSparseGrid2D} with default values. The defaults are a display of 400 x 400 pixels with a white background and red circular agents (instead of
	 * custom-specified agent portrayals).
	 * @param state the simulation that this GUI controls
	 */
	public GUIStateSparseGrid2D(SimStateSparseGrid2D state) {
		super(state);
		stateSparseGrid = state;
		gridWidth = 400;
		gridHeight = 400;
		backdrop = Color.WHITE;
		agentDefaultColor = Color.RED;
		defaultPortrayal = true;
	}

	public GUIStateSparseGrid2D(SimStateSparseGrid2D state, int gridWidth, int gridHeight, Color backdrop, Color agentDefaultColor,
			boolean defaultPortrayal) {
		super(state);
		stateSparseGrid = state;
		this.gridWidth = gridWidth;
		this.gridHeight = gridHeight;
		this.backdrop = backdrop;
		this.agentDefaultColor = agentDefaultColor;
		this.defaultPortrayal = defaultPortrayal;
	}

	public void start() {
		super.start();
		setupPortrayals(); // add setupPortrayals method below
		return;
	}

	public void quit() {
		super.quit();

		if (displayFrame != null) {
			displayFrame.dispose(); 
		}
		displayFrame = null;		// when quitting get rid of the display
		display = null;
		return;
	}

	public void load(SimStateSparseGrid2D state) {
		super.load(state);
		setupPortrayals();	// call setupPortrayals
		return;
	}


	/**
	 * This method is the most likely to change by simulation.
	 * Specifically, we define what agents look like here.  
	 */ 
	public void setupPortrayals() {
		agentsPortrayalSparseGrid.setField(stateSparseGrid.space);  // Change to your extended SimState class
		// Assumes your SparseGrid2D space is named "space"

		// This complicated statement makes an oval portrayal of a given color
		if (defaultPortrayal) {
			OvalPortrayal2D o = new OvalPortrayal2D(agentDefaultColor);  
			agentsPortrayalSparseGrid.setPortrayalForAll(o);  				// sets all the agents to the defined default color
		}
		display.reset();	// call the predefined reset method for the display
		display.repaint();	// call the repaint method
		return;
	}

	/**
	 * Creates an oval portrayal 2D and color and opacity are set by the parameters.
	 */
	public void setOvalPortrayal2DColor(Object obj, float red, float green, float blue, float opacity) {
		Color c = new Color(red, green, blue, opacity);
		OvalPortrayal2D o = new OvalPortrayal2D(c);
		agentsPortrayalSparseGrid.setPortrayalForObject(obj, o);
		return;
	}	

	/**
	 * Creates an oval portrayal 2D and color and opacity are set by the parameters.
	 */
	public void setOvalPortrayal2DColor(Object obj, float red, float green, float blue, float opacity, boolean filled) {
		Color c = new Color(red, green, blue, opacity);
		OvalPortrayal2D o = new OvalPortrayal2D(c, filled);
		agentsPortrayalSparseGrid.setPortrayalForObject(obj, o);
		return;
	}

	/**
	 * Creates an oval portrayal 2D and color and opacity are set by the parameters.
	 */
	public void setOvalPortrayal2DColor(Object obj, float red, float green, float blue, float opacity, boolean filled, double scale){
		Color c = new Color(red, green, blue, opacity);
		OvalPortrayal2D o = new OvalPortrayal2D(c, scale, filled);
		agentsPortrayalSparseGrid.setPortrayalForObject(obj, o);
		return;
	}

	public void init(Controller c) {
		super.init(c);
		display = new Display2D(gridWidth, gridHeight, this);			// make the display
		displayFrame = display.createFrame();
		c.registerFrame(displayFrame);									// let the controller control the frame
		displayFrame.setVisible(true);
		display.setBackdrop(backdrop);									// set the background color
		display.attach(agentsPortrayalSparseGrid, "Agent Space");		// attach the spatial environment to the display 
		return;
	}

	public Object getSimulationInspectedObject() {
		return state; 								// This returns the simulation; this is how MASON knows what class to populate the GUI's Model tab from
	}

	/**
	 * The initialize method allows you to create a basic user interface by supplying the appropriate parameters. The <i>simstateGrid</i> parameter must come from a class that extends
	 * {@link SimStateSparseGrid2D}, created by you to represent the simulation; for example by passing <tt>Environment.class</tt> as a parameter. The <i>gUIsubClass</i> parameter must
	 * come from a class that extends {@link GUIStateSparseGrid2D}, created by you to run the simulation; for example by passing MyGUI.class as a parameter. The color parameters must be
	 * an instance of the {@link Color} class; this comes with convenient colors that you do not need to make on your own, such as Color.WHITE, Color.RED, and Color.BLUE, each of which
	 * does what you expect it does (all of the primary colors are available). The <i>defaultPortrayal</i> parameter indicates whether the <i>agentDefaultColor</i> should be used to display
	 * agents as a circle of the given color (if <tt>true</tt>); if you pass <tt>false</tt> in this parameter, you must provide your own portrayals for agents.
	 * @param simstateGrid the class of the simulation state
	 * @param gUIsubClass the class of the GUI
	 * @param gridWidth width of display window
	 * @param gridHeight height of display window
	 * @param backdrop color of the window's background 
	 * @param agentDefaultColor color of default oval portrayal for all agents
	 * @param defaultPortrayal <tt>true</tt> to use default agent portrayals, <tt>false</tt> to specify a portrayal
	 */
	public static void initialize(Class<? extends SimStateSparseGrid2D> simstateGrid, Class<? extends GUIStateSparseGrid2D> gUIsubClass, int gridWidth, int gridHeight,
			Color backdrop, Color agentDefaultColor, boolean defaultPortrayal) {
		SimStateSparseGrid2D s = null;
		theClass = gUIsubClass;
		long seed = System.currentTimeMillis();
		try {
			s = (SimStateSparseGrid2D)(simstateGrid.getConstructor(long.class).newInstance(seed));
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}

		if (s != null) {
			agentsPortrayalSparseGrid = new SparseGridPortrayal2D();
			GUIStateSparseGrid2D ex = null;
			try {
				ex = (GUIStateSparseGrid2D)(gUIsubClass.getConstructor(SimStateSparseGrid2D.class, int.class, int.class, Color.class, Color.class, boolean.class)
						.newInstance(s, gridWidth, gridHeight, backdrop, agentDefaultColor, defaultPortrayal));
			} catch (InstantiationException |IllegalAccessException |IllegalArgumentException |InvocationTargetException
					|NoSuchMethodException |SecurityException e) {
				e.printStackTrace();
			}
			Console c = new Console(ex);
			s.attachGUI(ex);
			c.setVisible(true);
			System.out.println("Starting Simulation");
		} else {
			System.out.println("Failed to create instance of GUIStateSparseGrid2D.");
		}
		return;
	}

	public static String getName() { 
		return "Uses GUIStateSparseGrid2D"; 
	}

	public static Object getInfo() {
		java.net.URL url = theClass.getResource("index.html");
		if (url == null) {
			return "<html><head><title></title></head><body bgcolor=\"white\"></body></html>";
		}
		return url;
	}

}
