package states;

import sim.engine.SimState;
import sim.field.continuous.Continuous2D;

/**
 * This class extends MASON's {@link SimState}, providing a simulation engine that
 * also has easy access to a predefined spatial representation (a continuous 2D
 * plane created by invoking {@link #makeSpace}) and easy connection to a graphical
 * user interface (set by invoking {@link #setGui}. The spatial environment is a
 * 2D, continuous, Cartesian space. See {@link Continuous2D} for more details on
 * the spatial environment that is built into this simulation; continuous space has
 * some complexities, so reading that documentation is strongly recommended. See
 * {@link SimState} for the simulation facilities that come along with that class
 * as a parent.
 * @author Jeffrey C. Schank
 * @author Matt L. Miller
 */
@SuppressWarnings("serial")
public class SimStateContinuous2D extends SimState {
	protected GUIStateContinuous2D gui = null;
	protected Continuous2D space = null;

	/**
	 * Create a new simulation system with the random number generator seed set to
	 * <i>seed</i>.
	 * @param seed PRNG seed for simulation
	 */
	public SimStateContinuous2D(long seed) {
		super(seed);
	}

	public Continuous2D acquireSpace() {
		return space;
	}
	
	public GUIStateContinuous2D acquireGUI() {
		return gui;
	}

	public void attachGUI(GUIStateContinuous2D gui) {
		this.gui = gui;
		return;
	}

	/**
	 * Create a new environment for the simulation, a continuous, 2D Cartesian
	 * plane based on {@link Continuous2D}; you should see this documentation for
	 * a complete explanation of the discretization parameter, which is important
	 * for neighborhood searches to work efficiently (and, for non-point objects,
	 * for such searches to work correctly).
	 * @param discretization radius size for searches
	 * @param gridWidth environment width
	 * @param gridHeight environment height
	 * @return the new spatial environment
	 */
	public Continuous2D makeSpace(double discretization, double gridWidth, double gridHeight) {
		space = new Continuous2D(discretization, gridWidth, gridHeight);
		return space;
	}

}
