package states;

import sim.engine.SimState;
import sim.field.grid.SparseGrid2D;

/**
 * This class extends MASON's {@link SimState}, providing a simulation engine that
 * also has easy access to a predefined spatial representation (a grid created by
 * invoking {@link #makeSpace}) and easy connection to a graphical user interface
 * (set by invoking {@link #setGui}. The spatial environment is a simple, 2D,
 * discrete, Cartesian space that can hold more than one agent at each location.
 * See {@link SparseGrid2D} for more details on the spatial environment that is
 * built into this simulation and {@link SimState} for the simulation facilities
 * that come along with that class as a parent.
 * @author Jeffrey C. Schank
 * @author Matt L. Miller
 */
@SuppressWarnings("serial")
public class SimStateSparseGrid2D extends SimState {
	protected GUIStateSparseGrid2D gui = null;
	protected SparseGrid2D space = null;

	/**
	 * Create a new simulation system with the random number generator seed set to
	 * <i>seed</i>.
	 * @param seed PRNG seed for simulation
	 */
	public SimStateSparseGrid2D(long seed) {
		super(seed);
	}
	
	public SparseGrid2D acquireSpace() {
		return space;
	}

	public GUIStateSparseGrid2D acquireGUI() {
		return gui;
	}

	public void attachGUI(GUIStateSparseGrid2D gui) {
		this.gui = gui;
		return;
	}
	
	public boolean hasGUI() {
		return gui != null;
	}

	/**
	 * Create a new environment for the simulation, a discrete, 2D Cartesian
	 * grid of spaces based on {@link SparseGrid2D}.
	 * @param gridWidth environment width
	 * @param gridHeight environment height
	 * @return the new spatial environment
	 */
	public SparseGrid2D makeSpace(int gridWidth, int gridHeight) {
		space = new SparseGrid2D(gridWidth, gridHeight);
		return space;
	}

}
